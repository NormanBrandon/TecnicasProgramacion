﻿

namespace BibliotecaPractica
{
    public class Clase2
    {
        public static int Suma(int numero1, int numero2, int numero3)
        {
            
            int resultado = numero1 + numero2 + numero3;
            return resultado;
        }

        public static string AlumnoRegular()
        {
            string sitacademica = "Regular";
            return sitacademica;

        }

    }
}
