﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica9
{
    interface IMetodosIncompatibles
    {
        int Ventalibre(int numero);
        string EfectosSecundarios();
    }
}
